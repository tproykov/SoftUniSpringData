package softuni.exam.enums;

public enum DeviceType {
    SMART_PHONE,
    TABLET,
    SMART_WATCH,
    LAPTOP
}
